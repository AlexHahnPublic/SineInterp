#ifndef _LINEAR_SINE_H_
#define _LINEAR_SINE_H_
#include <cmath>
#include <vector>
#include <map>
#include <tuple>
#include <functional>
#include <cstdio>
#include "sineTest.h"
#define pi 3.141592653589793238462643383279502884

// In c++, structs are much like classes, except they default to public
// class LinearSine : public SinePrototype would also work here
struct LinearSine : SinePrototype
{
    private:
        double* Sn;
        double** coefOfLn;
        double* coefn;
        int nm;

    void S() {
        // fill out Sn
        Sn[0] = 0.;
        Sn[1] = 1.;
        for (int i = 2; i <= nm; i++) {
            Sn[i] = (i%2 == 0) ? 0 : 1 - (i-1)*i*Sn[i-2]/pi/pi;
            // printf("S(%d) = %f\n",i,Sn[i]);
        }
    }

    void coefOfL(int n){
        // invariant, coefOfL(n-1) has been called
        coefOfLn[n] = (double*)malloc(sizeof(double)*(n+3));
        if (n == 0) {
            coefOfLn[n][0] = 1.;
        } else if (n == 1) {
            coefOfLn[n][0] = 0.;
            coefOfLn[n][1] = 1.;
        } else {
            double* a = coefOfLn[n-1];
            double* b = coefOfLn[n-2];
            b[n-1] = 0; b[n] = 0;
            coefOfLn[n][0] = -(n-1.0)*b[0]/n;
            // printf("coefOfL(%d)[%d] = %f\n",n,0,coefOfLn[n][0]);
            for (int i = 1; i <= n; i++) {
                coefOfLn[n][i] = ((2*n-1)*a[i-1] - (n-1.0)*b[i])/n;
                // printf("coefOfL(%d)[%d] = %f\n",n,i,coefOfLn[n][i]);
            }
        }
    }

    double innerSin(int n) {
        // computes <sin(x), Ln(x)>
        double* c = coefOfLn[n];
        double ret = 0.0;
        for (int i = 0; i <= n; i++) {
            ret += 2*c[i]*Sn[i];
        }
        return ret;
    }

    double innerL(int n) {
        // computes <Ln(x), Ln(x)>
        double* c = coefOfLn[n];
        double* r = (double*)malloc(sizeof(double)*(2*n+1));
        for (int i = 0; i < 2*n+1; i++) {
            r[i] = 0;
        }
        for (int i = 0; i <= n; i++) {
            double x = c[i];
            for (int j = 0; j <= n; j++) {
                double y = c[j];
                r[i+j] += x*y;
            }
        }
        // r is the coefficient of (x/pi)^k
        // compute r . \int_{-\pi}^\pi (x/pi)^k dx = r . \frac{1}{k+1} = 2pi/(2k+1)
        double ret = 0;
        for (int i = 0; i < 2*n+1; i++) {
            ret += r[i]*2*pi/(i+1);
        }
        return ret;
    }

    void coef() {
        for (int k = 0; k <= nm; k++) {
            coefn[k] = innerSin(k)/innerL(k);
            // printf("%f, %f\n",innerSin(k), innerL(k));
        }
    }

    double evalL(double x) {
        double a = 1.0, b = x/pi;
        double ret = coefn[0] + b * coefn[1];
        if (nm == 0) return coefn[0];
        if (nm == 1) return ret;
        for (int n = 2; n <= nm; n++) {
            double c = ((x/pi)*(2*n-1)*b - (n-1)*a)/n;
            a = b; b = c;
            // printf("L[%d](x) = %f\n",n,c );
            ret += coefn[n] * c;
        }
        return ret;
    }

    public:
    // Define your functions here 
    // Class Constructor
	LinearSine(const int nn) : SinePrototype()  
    {
        // Initialize and prepare interpolation of sine
        // nm = 20 ? nn > 20 : nn;
        nm = nn;
        Sn = (double*)malloc(sizeof(double)*(nn+1));
        coefOfLn = (double**)malloc(sizeof(double*)*(nn+1));
        S();
        for (int i = 0; i <= nn; i++) coefOfL(i);
        coefn = (double*)malloc(sizeof(double)*(nn+1));
        coef();
    }

    // Your sine function
	double sine(double x) {
        // -evalL(x-pi) = sin(x)
        return -evalL(x-pi);
	}

};
#endif
