Go to the directory ChebSine (the one containing all of our files)

In the terminal type:
	
	make

This will compile a program sineTest. Then type:
	
	./sineTest
	
This will run the tester and spit out some results
