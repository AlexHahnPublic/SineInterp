#! /usr/bin/python
import glob
import os, sys
os.chdir(sys.path[0])
g = glob.glob('./*.txt')
files = map(lambda file: open(file).read(), g)

import re
c = re.compile(r'(.+?)s per')
mtime = [(lambda x: x[0])(map(float,c.findall(f))) for f in files]

time = [(lambda x: x[1]/x[0])(map(float,c.findall(f))) for f in files]
d = re.compile(r'/(.+?)\.txt')

times = dict(zip(map(lambda x: d.findall(x)[0], g),time))
mtimes = dict(zip(map(lambda x: d.findall(x)[0], g),mtime))

a = re.compile(r'm Error.+= (.+)')
acc = [float(a.findall(f)[1]) for f in files]

accs = dict(zip(map(lambda x: d.findall(x)[0], g),acc))

#for key in accs:
#	print "opt(%s): error = %s, multiple of machine sine = %s, machine sine = %ss"%(key, accs[key], times[key], mtimes[key])

# collect summary statistics: fastest, slowest, best error, worst error 
class Multimap(dict):
    def __setitem__(self, key, value):
        if key not in self:
            dict.__setitem__(self, key, [value])  # call super method to avoid recursion
        else:
            self[key].append(value)

invaccs = Multimap()
invtimes = Multimap()

for key in accs:
	invaccs[accs[key]] = key
	invtimes[times[key]] = key

aa = sorted(invaccs.keys())
best_a = aa[0]; worst_a = aa[-1]
tt = sorted(invtimes.keys())
best_t = tt[0]; worst_t = tt[-1]

#print "fastest: %s(%sx), slowest: %s(%sx)"%(invtimes[best_t],best_t,invtimes[worst_t],worst_t)
#if best_a == worst_a:
#	print "same accuracy for all flags: %s"%(best_a)
#else:
#	print "best accuracy: %s(%s), worst accuracy: %s(%s)"%(invaccs[best_a], best_a,invaccs[worst_a],worst_a)

keys = ['g','default','loop','O','O2','O3','fast']
data = map(lambda x: times[x], keys)
s = '''
data = %s;
plot(data)
keys = ['g   ';
'def ';
'loop';
'O   ';
'O2  ';
'O3  ';
'fast'];
set(gca,'XTickLabel',keys)
xlabel('Optimization Flag')
ylabel('times')
'''%(data)

print s
