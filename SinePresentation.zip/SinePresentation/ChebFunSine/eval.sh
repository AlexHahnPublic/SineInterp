make -B > default.txt
make -B O=-O > O.txt
make -B O=-O2 > O2.txt
make -B O=-O3 > O3.txt
make -B O=-g > g.txt
make -B O=-funroll-loops > loop.txt
make -B O=-Ofast > fast.txt